
     
		function Borrar(id)
		{
			document.getElementById('legajoParaBorrar').value = id;
			document.frmBorrar.submit();
		}
		function Modificar(id)
		{
			document.getElementById('legajoParaModificar').value = id;
			document.frmModificar.submit();
		}
   